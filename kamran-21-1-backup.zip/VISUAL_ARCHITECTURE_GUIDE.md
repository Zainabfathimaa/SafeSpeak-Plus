# 🎨 Visual Architecture & Flow Guide

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                        CLIENT SIDE (Frontend)                       │
│                        (React in Browser)                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │ Landing Page │  │Register Page │  │  Login Page  │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
│                              ▲                                      │
│                              │                                      │
│                    ┌─────────┴─────────┐                           │
│                    │                   │                           │
│              authService.js  +  localStorage                       │
│              (API Calls)     (Token Storage)                       │
│                    │                   │                           │
│                    └─────────┬─────────┘                           │
│                              │                                      │
│                              ▼                                      │
│                        HTTP / HTTPS                                │
│                      (REST Requests)                               │
│                                                                     │
└────────────────────────────────┬──────────────────────────────────┘
                                 │
                                 │ POST /api/auth/register
                                 │ POST /api/auth/login
                                 │ POST /api/auth/anonymous-login
                                 │ GET  /api/auth/me
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    SERVER SIDE (Backend)                            │
│                  (Node.js + Express)                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────┐          │
│  │                  Express Server                      │          │
│  │  (Listens on http://localhost:5000)                 │          │
│  └────────────────┬────────────────────────────────────┘          │
│                   │                                                 │
│        ┌──────────┴──────────────┐                                 │
│        │                         │                                 │
│        ▼                         ▼                                 │
│  ┌──────────────┐        ┌──────────────┐                         │
│  │  Middleware  │        │    Routes    │                         │
│  │              │        │              │                         │
│  │ • CORS       │        │ • /register  │                         │
│  │ • JSON       │        │ • /login     │                         │
│  │ • Auth Token │        │ • /auth/me   │                         │
│  └──────┬───────┘        └──────┬───────┘                         │
│         │                       │                                 │
│         └───────────┬───────────┘                                 │
│                     │                                             │
│                     ▼                                             │
│           ┌──────────────────┐                                    │
│           │   Controllers    │                                    │
│           │                  │                                    │
│           │ • register()     │                                    │
│           │ • login()        │                                    │
│           │ • anonymousLogin │                                    │
│           └────────┬─────────┘                                    │
│                    │                                              │
│                    ▼                                              │
│           ┌──────────────────┐                                    │
│           │      Models      │                                    │
│           │                  │                                    │
│           │ • User Schema    │                                    │
│           │ • Validation     │                                    │
│           │ • Methods        │                                    │
│           └────────┬─────────┘                                    │
│                    │                                              │
│                    ▼                                              │
└────────────────────┬──────────────────────────────────────────────┘
                     │
                     │ Query/Save Data
                     │ (MongoDB Protocol)
                     │
                     ▼
         ┌───────────────────────────┐
         │   DATABASE (MongoDB)      │
         │                           │
         │ ┌───────────────────────┐ │
         │ │  safespeak-plus db    │ │
         │ │  ├── users collection │ │
         │ │  │   ├── id           │ │
         │ │  │   ├── email        │ │
         │ │  │   ├── password     │ │
         │ │  │   ├── anonymousCode
         │ │  │   └── timestamps   │ │
         │ │  └── ...              │ │
         │ └───────────────────────┘ │
         └───────────────────────────┘
```

---

## Data Flow: Registration

```
┌─────────────────────────────────────────────────────────┐
│ STEP 1: User Input                                      │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ User fills RegisterPage:                            │ │
│ │ • Email: alice@college.edu                          │ │
│ │ • Password: Alice12345                              │ │
│ │ • Confirm: Alice12345                               │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 2: Frontend Validation                             │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ RegisterPage.jsx checks:                            │ │
│ │ ✓ Passwords match?                                  │ │
│ │ ✓ Password >= 6 characters?                         │ │
│ │ ✓ Email format valid?                               │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 3: API Call                                        │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ authService.registerUser(email, password,           │ │
│ │                         confirmPassword)            │ │
│ │                                                      │ │
│ │ Sends HTTP POST:                                    │ │
│ │ URL: http://localhost:5000/api/auth/register       │ │
│ │ Body: {email, password, confirmPassword}            │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 4: Backend Processing (authController.register)   │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ 1. Validate inputs                                   │ │
│ │    ├─ Email exists?                                │ │
│ │    ├─ Password strong?                             │ │
│ │    └─ Passwords match?                             │ │
│ │                                                      │ │
│ │ 2. Check database                                   │ │
│ │    └─ Is email already registered?                 │ │
│ │                                                      │ │
│ │ 3. Create user object                              │ │
│ │    └─ new User({email, password})                  │ │
│ │                                                      │ │
│ │ 4. Generate anonymous code                         │ │
│ │    └─ Format: ABC-123-DEF                          │ │
│ │                                                      │ │
│ │ 5. Save to database                                │ │
│ │    ├─ Pre-save hook triggers                       │ │
│ │    ├─ Password encrypted with bcrypt              │ │
│ │    └─ Saved to MongoDB                             │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 5: Database Operation (MongoDB)                    │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ BEFORE Encryption:                                  │ │
│ │ password: "Alice12345"                              │ │
│ │                                                      │ │
│ │ Pre-save Hook:                                      │ │
│ │ bcryptjs.hash("Alice12345", salt)                  │ │
│ │                                                      │ │
│ │ AFTER Encryption:                                   │ │
│ │ password: "$2b$10$nOUIs5kJ7naT...encrypted..."   │ │
│ │                                                      │ │
│ │ Document Saved:                                     │ │
│ │ {                                                    │ │
│ │   _id: ObjectId,                                   │ │
│ │   email: "alice@college.edu",                      │ │
│ │   password: "$2b$10$nOUIs5kJ...",                  │ │
│ │   anonymousCode: "BXK-456-PLM",                    │ │
│ │   createdAt: 2026-01-15T09:15:00Z,                 │ │
│ │   ...                                               │ │
│ │ }                                                    │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 6: Response Sent Back                              │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ HTTP 201 Created                                    │ │
│ │ {                                                    │ │
│ │   "success": true,                                  │ │
│ │   "message": "Registration successful",             │ │
│ │   "user": {                                         │ │
│ │     "id": "65a7f8c9d2e5f3g1h2i3j4k5",             │ │
│ │     "email": "alice@college.edu",                  │ │
│ │     "anonymousCode": "BXK-456-PLM"                │ │
│ │   }                                                 │ │
│ │ }                                                    │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 7: Frontend Receives Response                      │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ if (response.success) {                             │ │
│ │   ✓ Show success message                            │ │
│ │   ✓ Display anonymous code                         │ │
│ │   ✓ setSuccess(true)                               │ │
│ │   ✓ Show success screen                            │ │
│ │   ✓ Redirect to login after 5 seconds             │ │
│ │ }                                                    │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 8: User Sees                                       │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ ✅ Registration Successful!                         │ │
│ │                                                      │ │
│ │ Your Anonymous Access Code:                         │ │
│ │ ╔════════════════════════════════╗                 │ │
│ │ ║        BXK-456-PLM              ║                 │ │
│ │ ╚════════════════════════════════╝                 │ │
│ │                                                      │ │
│ │ ✓ Email & Password login supported                 │ │
│ │ ✓ Anonymous Code login supported                   │ │
│ │                                                      │ │
│ │ Redirecting to login in 5 seconds...               │ │
│ └─────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

## Data Flow: Login with Email

```
┌─────────────────────────────────────────────────────────┐
│ STEP 1: User Input                                      │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ User fills LoginPage (Email Mode):                  │ │
│ │ • Email: alice@college.edu                          │ │
│ │ • Password: Alice12345                              │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 2: API Call                                        │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ authService.loginUser(email, password)             │ │
│ │                                                      │ │
│ │ Sends HTTP POST:                                    │ │
│ │ URL: http://localhost:5000/api/auth/login          │ │
│ │ Body: {email, password}                             │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 3: Backend Processing (authController.login)      │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ 1. Validate inputs                                   │ │
│ │    ├─ Email provided?                              │ │
│ │    └─ Password provided?                           │ │
│ │                                                      │ │
│ │ 2. Find user by email                              │ │
│ │    └─ Query MongoDB: User.findOne({email})         │ │
│ │                                                      │ │
│ │ 3. Compare passwords                               │ │
│ │    ├─ Get password field (select: true)            │ │
│ │    ├─ bcryptjs.compare()                           │ │
│ │    ├─ Plain password vs encrypted hash             │ │
│ │    └─ Returns true if match                        │ │
│ │                                                      │ │
│ │ 4. Create JWT token (if match)                     │ │
│ │    ├─ jwt.sign({ userId, email })                 │ │
│ │    ├─ Using JWT_SECRET from .env                   │ │
│ │    ├─ Expires in 7 days                            │ │
│ │    └─ Token: eyJhbGciOiJIUzI1NiIsIn...            │ │
│ │                                                      │ │
│ │ 5. Update last login                               │ │
│ │    └─ user.lastLogin = new Date()                 │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 4: Password Comparison (Detailed)                  │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ User Entered: "Alice12345"                          │ │
│ │ Database Has: "$2b$10$nOUIs5kJ7naT..."            │ │
│ │                                                      │ │
│ │ bcryptjs.compare() does NOT:                        │ │
│ │ ✗ Decrypt the hash                                 │ │
│ │ ✗ Compare strings directly                         │ │
│ │                                                      │ │
│ │ bcryptjs.compare() DOES:                            │ │
│ │ 1. Extract salt from hash: nOUIs5kJ7naT           │ │
│ │ 2. Hash user input with same salt                  │ │
│ │    hash("Alice12345", salt) → Result1             │ │
│ │ 3. Compare Result1 with stored hash                │ │
│ │    Result1 == "$2b$10$..." ?                       │ │
│ │ 4. Return true/false                               │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 5: JWT Token Structure                             │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ Token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...  │ │
│ │                                                      │ │
│ │ Header (base64url encoded):                         │ │
│ │ {                                                    │ │
│ │   "alg": "HS256",                                   │ │
│ │   "typ": "JWT"                                      │ │
│ │ }                                                    │ │
│ │                                                      │ │
│ │ Payload (base64url encoded):                        │ │
│ │ {                                                    │ │
│ │   "userId": "65a7f8c9d2e5f3g1h2i3j4k5",          │ │
│ │   "email": "alice@college.edu",                    │ │
│ │   "iat": 1705344600,                               │ │
│ │   "exp": 1706122200                                │ │
│ │ }                                                    │ │
│ │                                                      │ │
│ │ Signature (HMAC-SHA256):                            │ │
│ │ HMACSHA256(                                         │ │
│ │   base64(header) + "." + base64(payload),          │ │
│ │   JWT_SECRET                                       │ │
│ │ )                                                    │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 6: Response Sent                                   │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ HTTP 200 OK                                         │ │
│ │ {                                                    │ │
│ │   "success": true,                                  │ │
│ │   "message": "Login successful",                    │ │
│ │   "token": "eyJhbGciOiJIUzI1NiIsInR5...",         │ │
│ │   "user": {                                         │ │
│ │     "id": "65a7f8c9d2e5f3g1h2i3j4k5",             │ │
│ │     "email": "alice@college.edu",                  │ │
│ │     "fullName": "Alice Smith"                      │ │
│ │   }                                                 │ │
│ │ }                                                    │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 7: Frontend Receives & Stores Token                │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ if (response.success) {                             │ │
│ │   // Save token to localStorage                     │ │
│ │   localStorage.setItem(                             │ │
│ │     'token',                                        │ │
│ │     'eyJhbGciOiJIUzI1NiIsInR5...'                  │ │
│ │   );                                                │ │
│ │                                                      │ │
│ │   // Redirect to dashboard                         │ │
│ │   navigate('/dashboard');                           │ │
│ │ }                                                    │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 8: Token Stored (Browser's Local Storage)          │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ localStorage:                                        │ │
│ │ {                                                    │ │
│ │   "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9" │ │
│ │ }                                                    │ │
│ │                                                      │ │
│ │ Persists across:                                    │ │
│ │ ✓ Page refresh                                      │ │
│ │ ✓ Browser close & reopen                          │ │
│ │ ✓ New tabs                                         │ │
│ │                                                      │ │
│ │ Expires after:                                      │ │
│ │ ✗ 7 days (JWT expiration)                          │ │
│ │ ✗ Manual logout                                    │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 9: User Sees Dashboard                             │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ Redirected to: http://localhost:5173/dashboard     │ │
│ │ Shows: Welcome, user data, reports, etc.            │ │
│ │ Token is now stored and ready for next requests     │ │
│ └─────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

## Token Usage in Protected Routes

```
┌─────────────────────────────────────────────────────────┐
│ User on Dashboard Wants to Get User Data                │
│ (Requires Authentication)                               │
└─────────────────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 1: Frontend Retrieves Token                        │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ const token = localStorage.getItem('token');        │ │
│ │ // token = "eyJhbGciOiJIUzI1NiIsInR5..."           │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 2: API Call with Token                             │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ fetch('http://localhost:5000/api/auth/me', {       │ │
│ │   method: 'GET',                                    │ │
│ │   headers: {                                        │ │
│ │     'Authorization': 'Bearer eyJhbGci...',         │ │
│ │     'Content-Type': 'application/json'              │ │
│ │   }                                                  │ │
│ │ })                                                   │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│ STEP 3: Backend Middleware Check (auth.js)             │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ middleware authenticate(req, res, next) {           │ │
│ │                                                      │ │
│ │   1. Get Authorization header                       │ │
│ │      req.headers.authorization                      │ │
│ │      = "Bearer eyJhbGci..."                         │ │
│ │                                                      │ │
│ │   2. Extract token                                  │ │
│ │      token = "eyJhbGci..."                          │ │
│ │                                                      │ │
│ │   3. Verify token                                   │ │
│ │      jwt.verify(token, JWT_SECRET)                 │ │
│ │      Does signature match?                          │ │
│ │      Is token expired?                              │ │
│ │                                                      │ │
│ │   4. If valid: Extract user data                    │ │
│ │      decoded = {                                    │ │
│ │        userId: "65a7f8c9d...",                     │ │
│ │        email: "alice@...",                          │ │
│ │        iat: 1705344600,                             │ │
│ │        exp: 1706122200                              │ │
│ │      }                                               │ │
│ │      req.user = decoded                             │ │
│ │      next() // Proceed to route handler             │ │
│ │                                                      │ │
│ │   5. If invalid: Return error                       │ │
│ │      res.status(401).json({                         │ │
│ │        success: false,                              │ │
│ │        message: "Unauthorized"                      │ │
│ │      })                                              │ │
│ │ }                                                    │ │
│ └─────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        │                         │
        ▼ (Valid)                 ▼ (Invalid)
   ┌─────────────┐             ┌─────────────┐
   │ Proceed     │             │ Return 401  │
   │ to Handler  │             │ Error       │
   └────────────┬┘             └──────┬──────┘
                │                     │
                ▼                     ▼
        ┌──────────────────┐   ┌──────────────────┐
        │ GET /api/auth/me │   │ Frontend Shows:  │
        │ Handler Runs     │   │ "Login expired"  │
        │ Uses req.user    │   │                  │
        │ Returns user data│   │ Clears token     │
        └────────┬─────────┘   │ Redirects to     │
                 │             │ login page       │
                 ▼             └──────────────────┘
        ┌──────────────────┐
        │ HTTP 200 OK      │
        │ {user data}      │
        └──────────────────┘
```

---

## Error Handling Flow

```
┌─────────────────────────────────────────────────────┐
│ API Request                                         │
└────────────────────┬────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        │                         │
        ▼                         ▼
   ┌──────────────┐         ┌──────────────┐
   │ No Error     │         │ Error Occurs │
   │ Success!     │         │ (try-catch)  │
   └──────┬───────┘         └──────┬───────┘
          │                        │
          ▼                        ▼
   ┌──────────────┐         ┌──────────────┐
   │ Return 200   │         │ Catch Error  │
   │ Response     │         │ Check Type   │
   └──────┬───────┘         └──────┬───────┘
          │                        │
          │            ┌───────────┼───────────┐
          │            │           │           │
          │            ▼           ▼           ▼
          │      ┌───────┐  ┌───────┐   ┌────────┐
          │      │Network│  │Validation  │Backend │
          │      │Error  │  │Error       │Error   │
          │      └───┬───┘  └────┬──────┘   └──┬───┘
          │          │           │             │
          │          ▼           ▼             ▼
          │    ┌──────────────────────────────────┐
          │    │ Create Error Object              │
          │    │ {                                 │
          │    │   success: false,                 │
          │    │   message: "User friendly msg",   │
          │    │   error: "ERROR_CODE"             │
          │    │ }                                 │
          │    └──────────────┬───────────────────┘
          │                   │
          └───────┬───────────┘
                  │
                  ▼
          ┌──────────────────┐
          │ Frontend Receives│
          │ Error Response   │
          └──────┬───────────┘
                 │
                 ▼
          ┌──────────────────┐
          │ Display Error    │
          │ to User          │
          │ setError(msg)    │
          └──────────────────┘
```

---

## Security & Data Protection

```
┌─────────────────────────────────────────────────────┐
│ Password Storage Example                            │
└─────────────────────────────────────────────────────┘

User Password: "Alice12345"
        │
        ▼ (Sent over HTTPS)
   Network
        │
        ▼ (Received at Backend)
   Pre-save Hook
        │
        ├─ Generate salt (random)
        │  salt = bcrypt.genSalt(10)
        │
        ├─ Hash password
        │  hash = bcrypt.hash(password, salt)
        │
        └─ Store hash (NOT password!)
        
Stored in Database: "$2b$10$nOUIs5kJ7naTuTFkBy1I.e..."
        │
        ├─ Can't be reversed
        ├─ Can't be decrypted
        ├─ Different every time (due to salt)
        └─ Same password produces same hash
        
Login: User enters "Alice12345" again
        │
        ▼
   bcrypt.compare(userInput, storedHash)
        │
        ├─ Extract salt from hash
        ├─ Hash userInput with same salt
        ├─ Compare result with storedHash
        └─ Returns true if match!
        
Attacker steals database:
        │
        ├─ Sees: "$2b$10$nOUIs5kJ7naTuTFkBy1I.e..."
        ├─ Can't reverse-engineer password
        ├─ Can't decrypt hash
        ├─ Rainbow tables ineffective (bcrypt adds salt)
        └─ Need to brute-force (very slow)
```

---

## Communication Protocols

```
┌─────────────────────────────────────────────────┐
│ HTTP Status Codes Used in This App              │
├─────────────────────────────────────────────────┤
│ 200 ✓ OK - Request successful                   │
│ 201 ✓ Created - Resource created successfully   │
│ 400 ✗ Bad Request - Client error                │
│ 401 ✗ Unauthorized - Auth failed                │
│ 404 ✗ Not Found - Route doesn't exist           │
│ 500 ✗ Server Error - Backend error              │
└─────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────┐
│ Request Headers We Send                         │
├─────────────────────────────────────────────────┤
│ Content-Type: application/json                  │
│ Authorization: Bearer <JWT_TOKEN>               │
└─────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────┐
│ Response Headers We Receive                     │
├─────────────────────────────────────────────────┤
│ Content-Type: application/json                  │
│ Access-Control-Allow-Origin: *                  │
│ Access-Control-Allow-Methods: *                 │
└─────────────────────────────────────────────────┘
```

---

## Conclusion

This visual guide shows:
- ✓ How data flows from frontend to backend
- ✓ How authentication is secured
- ✓ How tokens protect user data
- ✓ How errors are handled
- ✓ How encryption works

All integrated into SafeSpeak-Plus! 🎉

